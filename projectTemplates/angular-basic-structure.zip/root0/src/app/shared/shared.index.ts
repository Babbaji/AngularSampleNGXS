export const SHARED_COMPONENTS = [];
export const SHARED_PIPES = [];
