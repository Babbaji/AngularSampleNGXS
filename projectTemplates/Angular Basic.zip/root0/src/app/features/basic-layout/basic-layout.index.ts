import {BasicLayoutComponent} from './basic-layout.component';

export const BASIC_LAYOUT_COMPONENTS = [
  BasicLayoutComponent,
];
