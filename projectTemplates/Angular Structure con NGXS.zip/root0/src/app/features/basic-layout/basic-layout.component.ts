import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-layout',
  template: `
    <p>
      basic-layout works!
    </p>
  `,
  styles: []
})
export class BasicLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
