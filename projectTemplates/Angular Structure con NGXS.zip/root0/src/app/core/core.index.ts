export const CORE_SERVICES = [

];
