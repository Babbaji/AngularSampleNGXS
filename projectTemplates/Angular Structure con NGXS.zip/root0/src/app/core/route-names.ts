
export const BASIC_LAYOUT_ROUTES = {
  home: 'home'
};
