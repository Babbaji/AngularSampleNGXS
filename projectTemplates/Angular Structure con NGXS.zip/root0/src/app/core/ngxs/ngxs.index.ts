import {UserState} from './user/user.state';

export const CORE_STATES = [
  UserState
];
